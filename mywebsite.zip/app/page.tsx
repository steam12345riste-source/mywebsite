export default function Page() {
  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>WTF are you doing</title>
        <style dangerouslySetInnerHTML={{__html: `
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }

          body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #0a0a0a;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            padding: 1rem;
            position: relative;
            overflow: hidden;
          }

          /* Added animated background with floating orbs */
          body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
              radial-gradient(circle at 20% 50%, rgba(120, 40, 200, 0.15) 0%, transparent 50%),
              radial-gradient(circle at 80% 80%, rgba(40, 120, 200, 0.15) 0%, transparent 50%),
              radial-gradient(circle at 40% 90%, rgba(200, 40, 120, 0.15) 0%, transparent 50%);
            animation: backgroundMove 20s ease-in-out infinite;
            z-index: 0;
          }

          @keyframes backgroundMove {
            0%, 100% {
              transform: translate(0, 0) scale(1);
            }
            33% {
              transform: translate(-30px, -50px) scale(1.1);
            }
            66% {
              transform: translate(50px, 30px) scale(0.9);
            }
          }

          /* Added floating particles effect */
          body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
              radial-gradient(circle, rgba(255, 255, 255, 0.1) 1px, transparent 1px),
              radial-gradient(circle, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px, 80px 80px;
            background-position: 0 0, 40px 40px;
            animation: particlesFloat 60s linear infinite;
            z-index: 0;
          }

          @keyframes particlesFloat {
            0% {
              transform: translateY(0);
            }
            100% {
              transform: translateY(-100px);
            }
          }

          .container {
            text-align: center;
            max-width: 48rem;
            width: 100%;
            position: relative;
            z-index: 1;
          }

          h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #fafafa;
            margin-bottom: 2.5rem;
          }

          .section {
            margin-bottom: 2rem;
          }

          .section:last-child {
            margin-bottom: 0;
          }

          .section-title {
            font-size: 0.875rem;
            font-weight: 600;
            color: #71717a;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.75rem;
          }

          .button-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            justify-content: center;
          }

          .btn {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            font-weight: 500;
            color: #fafafa;
            background-color: transparent;
            border: 1px solid #27272a;
            border-radius: 0.375rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s ease;
            display: inline-block;
            /* Added backdrop blur for glassmorphism effect */
            backdrop-filter: blur(10px);
            background-color: rgba(24, 24, 27, 0.4);
          }

          .btn:hover {
            background-color: #18181b;
            border-color: #3f3f46;
            /* Enhanced hover state with glow effect */
            box-shadow: 0 0 20px rgba(120, 80, 200, 0.3);
          }

          .btn:active {
            transform: scale(0.98);
          }

          /* Added footer text in bottom right corner */
          .footer-text {
            position: fixed;
            bottom: 1rem;
            right: 1rem;
            font-size: 0.75rem;
            color: #71717a;
            z-index: 1;
          }
        `}} />
      </head>
      <body>
        <div className="container">
          <h1>Choose what website to try</h1>
          
          <div className="section">
            <div className="section-title">Search Engines</div>
            <div className="button-group">
              <a href="https://searxng-1-lr79.onrender.com/" target="_blank" rel="noopener noreferrer" className="btn">
                SearXNG Search
              </a>
              <a href="https://whoogle-search-1-ywia.onrender.com" target="_blank" rel="noopener noreferrer" className="btn">
                Whoogle Search
              </a>
              <a href="https://searx-fdzu.onrender.com" target="_blank" rel="noopener noreferrer" className="btn">
                Searx
              </a>
            </div>
          </div>

          <div className="section">
            <div className="section-title">Tools & Services</div>
            <div className="button-group">
              <a href="https://w.static.domains/" target="_blank" rel="noopener noreferrer" className="btn">
                crynex
              </a>
              <a href="https://w.steam12345riste.workers.dev/" target="_blank" rel="noopener noreferrer" className="btn">
                crywere
              </a>
              <a href="https://wtf.steam12345riste.workers.dev/" target="_blank" rel="noopener noreferrer" className="btn">
                crynexgpt
              </a>
            </div>
          </div>
        </div>

        <div className="footer-text">
          ahh that took way too long WTF are you doing
        </div>
      </body>
    </html>
  )
}
